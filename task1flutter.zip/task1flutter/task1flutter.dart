import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.blueGrey,
        appBar: AppBar(
          backgroundColor: Colors.black,
          leading: Icon(
            Icons.alarm,
            color: Colors.white,
          ),
          centerTitle: true,
          title: Text(
            'Hello World',
            style: TextStyle(
              color: Colors.white,
              fontSize: 30,
            ),
          ),
          actions: [
            Icon(
              Icons.accessibility,
              color: Colors.white,
              size: 40,
            ),
          ],
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 85,
                  height: 75,
                  color: Colors.blue,
                  child: Center(
                    child: Text(
                      'Hello World',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                      ),
                    ),
                  ),
                  alignment: Alignment.center,
                ),
                Container(
                  width: 75,
                  height: 75,
                  color: Colors.blue,
                  child: Icon(
                    Icons.add_card,
                    color: Colors.white,
                    size: 40,
                  ),
                ),
              ],
            ),
            Expanded(
              child: Center(
                child: Container(
                  width: 300,
                  height: 500,
                  color: Colors.black,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 40,
                        top: 45,
                        child: Container(
                          width: 50,
                          height: 50,
                          color: Colors.deepPurple,
                        ),
                      ),
                      Positioned(
                        right: 40,
                        top: 45,
                        child: Container(
                          width: 50,
                          height: 50,
                          color: Colors.deepPurple,
                        ),
                      ),
                      Positioned(
                        left: 140,
                        top: 200,
                        child: Container(
                          width: 20,
                          height: 100,
                          color: Colors.yellow,
                        ),
                      ),
                      Positioned(
                        left: 50,
                        bottom: 70,
                        child: Container(
                          width: 200,
                          height: 25,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
